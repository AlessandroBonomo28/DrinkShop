UNIVERSITÀ DEGLI STUDI DI NAPOLI FEDERICO II

SCUOLA POLITECNICA E DELLE SCIENZE DI BASE DIPARTIMENTO DI INGEGNERIA ELETTRICA E TECNOLOGIE DELL’INFORMAZIONE

CORSO DI LAUREA IN INFORMATICA

INSEGNAMENTO DI LABORATORIO DI SISTEMI OPERATIVI - ANNO ACCADEMICO 2022/2023

Sistema Informativo per la Gestione di un DrinkShop

-------------------------------

Autori

Alessandro Bonomo
N86003852
al.bonomo@studenti.unina.it

Mario De Luca
N86003911
mario.deluca10@studenti.unina.it

Nome gruppo: JuicyLemons

-------------------------------
Docente

Prof.ssa Alessandra Rossi
-------------------------------

Consultare la documentazione tecnica del progetto inclusa nella cartella.
Repository online: https://github.com/AlessandroBonomo28/DrinkShop
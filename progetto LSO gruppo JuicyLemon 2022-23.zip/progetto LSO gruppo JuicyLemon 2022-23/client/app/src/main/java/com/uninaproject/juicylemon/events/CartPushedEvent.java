package com.uninaproject.juicylemon.events;

public class CartPushedEvent { }

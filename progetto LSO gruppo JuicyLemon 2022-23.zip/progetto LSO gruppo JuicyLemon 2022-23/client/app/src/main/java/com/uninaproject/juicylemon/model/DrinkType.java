package com.uninaproject.juicylemon.model;

public enum DrinkType {
    FRULLATO,
    COCKTAIL
}

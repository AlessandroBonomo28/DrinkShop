package com.uninaproject.juicylemon.lemonExceptions;

public class UserException extends  Exception{
    public UserException(String message) {
        super(message);
    }
}

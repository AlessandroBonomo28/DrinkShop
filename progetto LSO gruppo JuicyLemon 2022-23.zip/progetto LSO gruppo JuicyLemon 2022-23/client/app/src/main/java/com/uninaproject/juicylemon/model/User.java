package com.uninaproject.juicylemon.model;

public class User {
    public int id;
    public String email;

    public User(int id, String email) {
        this.id = id;
        this.email = email;
    }
}

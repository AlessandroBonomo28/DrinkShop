#ifndef BCRYPT_H
#define BCRYPT_H
char* encrypt(const char* data);
#endif
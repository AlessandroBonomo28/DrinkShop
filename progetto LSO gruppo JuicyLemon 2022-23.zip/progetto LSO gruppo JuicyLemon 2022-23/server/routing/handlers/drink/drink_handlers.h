#ifndef DRINK_HANDLERS_H
#define DRINK_HANDLERS_H
#include "../../router/router.h"

void getDrinkImageHandler(RouterParams params);
void getDrinkHandler(RouterParams params);
void getDrinksHandler(RouterParams params);

#endif
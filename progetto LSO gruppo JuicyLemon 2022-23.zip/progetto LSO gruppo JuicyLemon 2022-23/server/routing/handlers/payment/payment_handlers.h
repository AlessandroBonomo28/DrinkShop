#ifndef PAYMENT_HANDLERS_H
#define PAYMENT_HANDLERS_H
#include "../../router/router.h"

void payOrderHandler(RouterParams params);

#endif
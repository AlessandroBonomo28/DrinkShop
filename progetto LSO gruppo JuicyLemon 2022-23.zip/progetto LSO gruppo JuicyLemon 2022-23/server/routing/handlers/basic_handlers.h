#ifndef HANDLERS_H
#define HANDLERS_H
#include "../router/router.h"

void homeHandler(RouterParams params);

#endif
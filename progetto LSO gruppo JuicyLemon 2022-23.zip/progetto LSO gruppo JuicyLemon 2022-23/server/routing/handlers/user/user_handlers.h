
#ifndef USER_HANDLERS_H
#define USER_HANDLERS_H
#include "../../router/router.h"

void loginHandler(RouterParams params);
void registerHandler(RouterParams params);
void getUserHandler(RouterParams params);
#endif